#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/types.h>

#ifndef DIJKSTRA_H 
#define DIJKSTRA_H 

int sem_create(key_t cle, int initval) {
    int semid;
    union semun {
        int val;
        struct semid_ds *buf;
        ushort *array;
    } arg_ctl;

    semid = semget(ftok("dijkstra.h", cle), 1, IPC_CREAT | IPC_EXCL | 0666);

    if (semid == -1) {
        semid = semget(ftok("dijkstra.h", cle), 1, 0666);
        if (semid == -1) {
            perror("Erreur semget()");
            exit(1); // Handle error appropriately
        }
    }

    arg_ctl.val = initval;
    if (semctl(semid, 0, SETVAL, arg_ctl) == -1) {
        perror("Erreur initialisation semaphore");
        exit(1); // Handle error appropriately
    }

    return semid;
}

void P(int semid) {
    struct sembuf sempar;
    sempar.sem_num = 0;
    sempar.sem_op = -1;
    sempar.sem_flg = SEM_UNDO;
   
    if (semop(semid, &sempar, 1) == -1) {
        perror("Erreur operation P");
        // Handle error appropriately
    }
}

void V(int semid) {
    struct sembuf sempar;
    sempar.sem_num = 0;
    sempar.sem_op = 1;
    sempar.sem_flg = SEM_UNDO;
   
    if (semop(semid, &sempar, 1) == -1) {
        perror("Erreur operation V");
        // Handle error appropriately
    }
}

void sem_delete(int semid) {
    if (semctl(semid, 0, IPC_RMID, 0) == -1) {
        perror("Erreur dans destruction semaphore");
        // Handle error appropriately
    }
}

#endif