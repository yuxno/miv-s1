#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <time.h>
#include "dijkstra.h"

//**************************DECLARATION***************************************
//sem declaration
int nvide,mutex,mutex1;
#define CLE1 1
#define CLE2 2
#define CLE3 3

#define BUFFER_SIZE 3
#define MAX_PROCESSUS 5

// Cles SHM for buffers
#define CLE_SHM1 27
#define CLE_SHM3 28
#define CLE_SHM4 29

int found=0;

typedef struct{
    int id;
    int type;
    int nb1;
    int nb2;
    int nb3;
}requet;

//buffer for freponse
typedef struct{
    int id;
    int accord;
}message;

struct msgbuf{
    long mtype;
    message mtext;
};

int freponse_id;

typedef struct{
    int id;
    int nb1;
    int nb2;
    int nb3;
}fliberer_msg;
int fliberer_id;

//buffer thing for trequest
typedef struct {
    int q;  // Index for the circular buffer
    requet trequest[BUFFER_SIZE];  // Circular buffer of size 3
    int cpt;
} shared_data;

shared_data *Trequet;


typedef struct {
    int nb1;
    int nb2;
    int nb3;
}availableRessources;

availableRessources ressources={50,50,50};

//structs tables

typedef struct demande{
    int nb1;
    int nb2;
    int nb3;
}demande;

typedef struct allocation{
    int alloc1;
    int alloc2;
    int alloc3;
}allocation;

typedef struct information{
    int etat;
    clock_t tempAtt;
} information;

demande demandes[5]={{0,0,0},{0,0,0},{0,0,0},{0,0,0},{0,0,0}};

allocation allocations[5]={{0,0,0}, {0,0,0},{0,0,0},{0,0,0},{0,0,0}};

information informations[5]={ {0,0}, {0,0} ,{0,0} ,{0,0} ,{0,0}};



//********************************INITS************************************

void init_sem(){
    nvide=sem_create(CLE1,3);
    mutex=sem_create(CLE2,1);
    mutex1=sem_create(CLE3,1);
}


void creerTampon() {
    int shmid;
    key_t key = ftok("./", CLE_SHM1);
    int size = sizeof(shared_data);

    if ((shmid = shmget(key, size, IPC_CREAT | 0666)) == -1) {
        perror("Echec de shmget");
        exit(1);
    }

    shared_data *mem;
    if ((mem = (shared_data *)shmat(shmid, NULL, 0)) == (shared_data *)-1) {
        perror("attachement impossible");
        exit(1);
    }
    mem->q=0;
    mem->cpt=0;
    Trequet = mem;
    printf("tampon created successfuly  \n");
}

void creerFreponse() {
   
    key_t key = ftok("./", CLE_SHM3);

    if ((freponse_id==msgget(key,IPC_CREAT | 0666))==-1){
        perror("Echec de shmget");
        exit(1);
    }
   
    printf("freponse created successfuly  \n");
}

void creerFliberer() {
   
    key_t key = ftok("./", CLE_SHM4);

    if ((fliberer_id==msgget(key,IPC_CREAT | 0666))==-1){
        perror("Echec de shmget");
        exit(1);
    }
   
    printf("fliberer created successfuly  \n");
}



//********************************FUNCTIONS********************************

void init_all(){

    init_sem();
    creerTampon();
    creerFreponse();
    creerFliberer();

}

void detruire_all()
{
    sem_delete(nvide);
    sem_delete(mutex1);
    sem_delete(mutex);

    shmdt((void *)Trequet);
    shmctl(shmget(ftok("./", CLE_SHM1), sizeof(shared_data),0),IPC_RMID,NULL);
    msgctl(freponse_id, IPC_RMID,NULL);
    msgctl(fliberer_id,IPC_RMID,NULL);
}
    

void demanderRessources(int id,int type, int nb1, int nb2, int nb3)
{
    requet req;
    req.id=id;
    req.type=type;
    req.nb1=nb1;
    req.nb2=nb2;
    req.nb3=nb3;
   
    P(mutex);
    Trequet->trequest[Trequet->q]= req;
    Trequet->q = (Trequet->q+1) % BUFFER_SIZE;
    V(mutex);

}

void envoyerReponse (int id, int accord){
    struct msgbuf buf;
    buf.mtype=id;
    buf.mtext.id=id;
    buf.mtext.accord=accord;
    
    if(msgsnd(freponse_id, &buf, sizeof(message), IPC_NOWAIT)==-1){
        perror("erreur lors de l'envoi du message");
        exit(1);
    }else{
        printf("message sent! id:%d, rep:%d\n", buf.mtext.id, buf.mtext.accord);
    }
}

int recevoireReponse(int id){
    struct msgbuf buf;
    int bb;


    while(1){
       bb= msgrcv(freponse_id, &buf, sizeof(message), id, IPC_NOWAIT);
    if(bb!=-1){
        printf("received msg: id:%d, reponse: %d\n",buf.mtext.id,buf.mtext.accord );
        if(buf.mtext.accord==1){
            return 1;
        }  
    }else if(errno==ENOMSG){
        sleep(1);
       
    }else{

        printf("im p %d and failed ig\n", id);
        perror("msgrcv failed");
        break;
    }
   
    }
}

void envoyerFliberer(int id,int nb1, int nb2, int nb3){

    fliberer_msg flib;
    flib.id=id;
    flib.nb1=nb1;
    flib.nb2=nb2;
    flib.nb3=nb3;

    if(msgsnd(fliberer_id, &flib, sizeof(fliberer_msg), IPC_NOWAIT)==-1){
        perror("erreur lors de l'envoi du message fliberer");
        exit(1);
    }else{
        printf("flib msg send ! id: %d \n", flib.id);
    }
}

fliberer_msg receiveFliberer(int fliberer_id){
    fliberer_msg rcv_msg;
    int bb;

   
        bb=msgrcv(fliberer_id, &rcv_msg, sizeof(fliberer_msg),0, IPC_NOWAIT);
        if(bb!=-1  ){
           printf("recived flibere msg: id %d\n", rcv_msg.id );
           return rcv_msg;
             
        }else if(errno==ENOMSG){
            sleep(1);
           
        }else{

           perror("msgrcv failed");
           exit(1);
          
        }
}

void liberer_finale(int id){

    ressources.nb1=ressources.nb1 + allocations[id].alloc1;
    ressources.nb2=ressources.nb2 + allocations[id].alloc2;
    ressources.nb3=ressources.nb3 + allocations[id].alloc3;

    allocations[id].alloc1=0;
    allocations[id].alloc2=0;
    allocations[id].alloc3=0;
    
    printf("disallocation finale done succesfully for p %d \n", id);

}

void giveRessource(requet request){

       allocations[request.id].alloc1=request.nb1;
       allocations[request.id].alloc2=request.nb2;
       allocations[request.id].alloc3=request.nb3;
       sleep(1);
        
       ressources.nb1 = (ressources.nb1 - request.nb1 >= 0) ? ressources.nb1 - request.nb1 : 0;
       ressources.nb2 = (ressources.nb2 - request.nb2 >= 0) ? ressources.nb2 - request.nb2 : 0;
       ressources.nb3 = (ressources.nb3 - request.nb3 >= 0) ? ressources.nb3 - request.nb3 : 0;
       
       informations[request.id].etat=1;
       informations[request.id].tempAtt=0;

       printf("allocation done succesfully to p%d \n", request.id);
}

int isDemandesNotEmpty() {
    for (int i = 0; i < MAX_PROCESSUS; ++i) {
        if (demandes[i].nb1 == 0 || demandes[i].nb2 == 0 || demandes[i].nb3 == 0) {
            return 0;  // empty
        }
    }
    return 1;  // not empty
}


void sortDemandes(int *processOrder) {
    // Populate processOrder array with process IDs
    for (int i = 0; i < MAX_PROCESSUS; ++i) {
        processOrder[i] = i+1;
    }

    // Sort the processOrder array based on tempAtt
    for (int i = 0; i < MAX_PROCESSUS - 1; ++i) {
        for (int j = 0; j < MAX_PROCESSUS - i - 1; ++j) {
            if (informations[processOrder[j] - 1].etat == 0 &&
                informations[processOrder[j + 1] - 1].etat == 0 &&
                informations[processOrder[j] - 1].tempAtt > informations[processOrder[j + 1] - 1].tempAtt) {
                // Swap processOrder[j] and processOrder[j + 1]
                int temp = processOrder[j];
                processOrder[j] = processOrder[j + 1];
                processOrder[j + 1] = temp;
            }
        }
    }
}

void sortDemandes2(int* processOrder2) {
    // Populate processOrder array with process IDs
    for (int i = 0; i < MAX_PROCESSUS; ++i) {
        processOrder2[i] = i+1;
    }

    // Sort the processOrder array based on tempAtt in descending order
    for (int i = 0; i < MAX_PROCESSUS - 1; ++i) {
        for (int j = 0; j < MAX_PROCESSUS - i - 1; ++j) {
            if (informations[processOrder2[j] - 1].etat == 0 &&
                informations[processOrder2[j + 1] - 1].etat == 0 &&
                informations[processOrder2[j] - 1].tempAtt < informations[processOrder2[j + 1] - 1].tempAtt) {
                // Swap processOrder[j] and processOrder[j + 1]
                int temp = processOrder2[j];
                processOrder2[j] = processOrder2[j + 1];
                processOrder2[j + 1] = temp;
            }
        }
    }
}


void satisfy(requet request)
     {
        int processOrder[MAX_PROCESSUS];  //for sorting dem without changing order of table
        sortDemandes(processOrder);

         for(int i=0;i<MAX_PROCESSUS;i++){
            int currentId=processOrder[i];
             if ((allocations[currentId].alloc1+ressources.nb1)>=request.nb1 && (allocations[currentId].alloc2+ressources.nb2)>=request.nb2 && ( allocations[currentId].alloc3+ressources.nb3)>=request.nb3){
                
                giveRessource(request);
            
                int remaining1=request.nb1 - ressources.nb1;
                int remaining2=request.nb2 - ressources.nb2;
                int remaining3=request.nb3 - ressources.nb3;

                //n9s allo w zid dem 
                allocations[currentId].alloc1 -= remaining1;
                allocations[currentId].alloc2 -= remaining2;
                allocations[currentId].alloc3 -= remaining3;

                demandes[currentId].nb1 += remaining1;
                demandes[currentId].nb2 += remaining2;
                demandes[currentId].nb3 += remaining3;

                found=1;
                printf(" i satisfied p %d using p %d \n", request.id, currentId);
             }
             }

             if (found==0){
                found=2;
             }
     
     }

void satisfyOthers(){
    int processOrder2[MAX_PROCESSUS];
    sortDemandes2(processOrder2);

    for (int i = 0; i < MAX_PROCESSUS; i++) {
        int currentId = processOrder2[i];
        if (ressources.nb1 >= demandes[currentId].nb1 &&
            ressources.nb2 >= demandes[currentId].nb2 &&
            ressources.nb3 >= demandes[currentId].nb3) {

            requet req;
            req.id = currentId;
            req.nb1 = demandes[currentId].nb1;
            req.nb2 = demandes[currentId].nb2;
            req.nb3 = demandes[currentId].nb3;

            giveRessource(req);

            demandes[currentId].nb1 = 0;
            demandes[currentId].nb2 = 0;
            demandes[currentId].nb3 = 0;

            printf("Satisfied blocked process %d\n", currentId);
            break;
            
        }
    }

}




//**************************CALCULE N GERANT******************************


void calcul(int id, char* instructions_file) {
   
    FILE *file;

    requet instruction;
 
    file = fopen(instructions_file, "r");
   
    if (file == NULL) {
        printf("Error opening the file.\n");
        return;
    }

    printf("File opened successfully!\n");

   
    do{
        while (fscanf(file, "%d %d %d %d", &instruction.type, &instruction.nb1, &instruction.nb2, &instruction.nb3) == 4) {
        switch (instruction.type) {
            case 1: // Instruction normale
                sleep(2);
                break;

            case 2: // Instruction de demande de ressources
                printf("im calcule %d n im askin for ressouces %d and %d and %d\n",id, instruction.nb1,instruction.nb2,instruction.nb3);
                sleep(1);

                P(nvide);
                demanderRessources(id,instruction.type, instruction.nb1, instruction.nb2, instruction.nb3);

                P(mutex1);
                (Trequet->cpt)++;
                V(mutex1);
               
                // printf("im calcule %d n im waitin for answers \n",id);
               
                sleep(2);
               
                int rep=recevoireReponse(id);
                while(rep!=1){
                    rep=recevoireReponse(id);
                }
                sleep(2);
               
                break;

            case 3: // Instruction de libération de ressources
                printf("im calcule %d n i want to free these ressources %d and %d and %d \n", id, instruction.nb1,instruction.nb2,instruction.nb3);
                envoyerFliberer(id,instruction.nb1,instruction.nb2,instruction.nb3);
                sleep(2);
               
                break;

            case 4:
                sleep(2);
                
                P(nvide);
                demanderRessources(id, instruction.type, 0, 0, 0);
               
                printf("proc %d and i finished (type 4) \n", id);

                P(mutex1);
                (Trequet->cpt)++;
                V(mutex1);
                exit(1);
           
            default:
                break;
        }
         
    }
    }while(instruction.type!=4);
   
    fclose(file);

}


void gerant(){

    
    requet request;
    fliberer_msg flib_msg;

    printf("Iam gerant and these are the available Ressources i have now at the beginning! nb1:%d,nb2: %d, nb3:%d \n", ressources.nb1, ressources.nb2, ressources.nb3);

    int nbproc=5;

    do{
        bool trouve=false;
   

        do{
            P(mutex1);
            if ((Trequet->cpt)!=0){
                trouve=true;
                V(mutex1);
               
                P(mutex);
                request=Trequet->trequest[Trequet->q];
                Trequet->q=(Trequet->q+1)%BUFFER_SIZE;
                V(mutex);

                P(mutex1);
                (Trequet->cpt)--;
                V(mutex1);
                V(nvide);

            }else{
             
                V(mutex1);
                //search in fliberer
                flib_msg=receiveFliberer(fliberer_id);
                if (flib_msg.id>=1 && flib_msg.id<=5){

                     P(mutex);
                    request.type=3;
                    V(mutex);
                    printf("im gerant and i found smth in fliberer, id: %d\n", flib_msg.id);
                    trouve=true;
                }
            }

           
        }while(trouve==false);

        switch (request.type){
            case 2:
               
                if(ressources.nb1>=request.nb1 && ressources.nb2>=request.nb2 && ressources.nb3>=request.nb3){

                    printf("\nim gerant and i will grant proc %d the ressources it want\n", request.id);

                    envoyerReponse(request.id,1);
                   
                    giveRessource(request);
                    sleep(2);

                    break;

                }else if(found==0) {

                    printf("i cant satisfy p%d so i will check if any of the p blocked can\n", request.id);
                    satisfy(request);

                }else if(found==2){

                    printf("\nim gerant and i cant grant proc %d the ressources it want\n", request.id);
                    envoyerReponse(request.id,0);
                    sleep(2);

                    demandes[request.id].nb1+=request.nb1;
                    demandes[request.id].nb2+=request.nb2;
                    demandes[request.id].nb3+=request.nb3;
                    informations[request.id].etat=0;
                    informations[request.id].tempAtt=clock();

                    sleep(2);

                }
                break;

            case 3:

                printf("ana gerant ran na7ilhm\n");

                allocations[flib_msg.id].alloc1=allocations[flib_msg.id].alloc1- flib_msg.nb1;
                allocations[flib_msg.id].alloc2=allocations[flib_msg.id].alloc2- flib_msg.nb2;
                allocations[flib_msg.id].alloc3=allocations[flib_msg.id].alloc3- flib_msg.nb3;

                ressources.nb1=ressources.nb1 + flib_msg.nb1;
                ressources.nb2=ressources.nb2 + flib_msg.nb2;
                ressources.nb3=ressources.nb3 + flib_msg.nb3;

                printf("disallocation done succesfully for p %dfor nb1 %d nb2 %d nb3 %d \n", request.id, request.nb1,request.nb2, request.nb3);
                sleep(2);

                if(isDemandesNotEmpty()){
                    satisfyOthers();
                   }
               
                break;

            case 4:
              
               liberer_finale(request.id);
               sleep(2);

               if(isDemandesNotEmpty()){
                satisfyOthers();
               }
               

                nbproc-=1;
                break;

        }
       
    }while(nbproc!=0);



}






//*********************************MAIN*******************************///


int main(){
   
    init_all();
   

    pid_t gerant_pid = fork();
 
     if (gerant_pid == 0) {
        gerant();
    } else if (gerant_pid > 0) {

         pid_t calcul_pids[MAX_PROCESSUS];

     // Create Calcul processes
     for (int i = 0; i < MAX_PROCESSUS; ++i) {
     calcul_pids[i] = fork();

     if (calcul_pids[i] == 0) {
        char filename[20];
        snprintf(filename,sizeof(filename), "fich[%d]",i+1);
         calcul(i + 1, filename); 
         exit(0);
    }
     }

    // Wait for all processes to finish
     for (int i = 0; i < MAX_PROCESSUS; ++i) {
     wait(NULL);
     }
     } else {
     perror("Fork failed");

     exit(EXIT_FAILURE);
     }

     printf("programme terminé! \n");

    //detruire all
     detruire_all();
    

    }



   
   
    
